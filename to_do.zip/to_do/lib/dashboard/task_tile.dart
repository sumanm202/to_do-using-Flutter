import 'package:flutter/material.dart';
import 'task_model.dart';

class TaskTile extends StatelessWidget {
  final Task task;
  final VoidCallback onDelete;

  const TaskTile({required this.task, required this.onDelete, super.key});

  @override
  Widget build(BuildContext context) {
    print('Building TaskTile for task: id=${task.id}, title=${task.title}, isCompleted=${task.isCompleted}');
    return ListTile(
      title: Text(task.title.isEmpty ? 'Untitled Task' : task.title),
      leading: Checkbox(
        value: task.isCompleted,
        onChanged: null,
      ),
      trailing: IconButton(
        icon: const Icon(Icons.delete),
        onPressed: onDelete,
      ),
    );
  }
}