import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'auth/auth_service.dart';
import 'auth/login_screen.dart';
import 'auth/signup_screen.dart';
import 'dashboard/dashboard_screen.dart';
import 'services/supabase_service.dart';
import 'app/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://jbebyvwbjftzennejqrj.supabase.co', // replace with your Supabase URL
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpiZWJ5dndiamZ0emVubmVqcXJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzMzMzOTYsImV4cCI6MjA2MDkwOTM5Nn0.MSUJaLuZGwMk0xKmb4ZPlaQYttfZlO3RMG0suCMSd0w', // replace with your anon public key
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Mini TaskHub',
        theme: AppTheme.lightTheme,
        home: const RootPage(),
      ),
    );
  }
}

class RootPage extends StatelessWidget {
  const RootPage({super.key});

  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;

    // show dashboard if logged in
    if (session != null) {
      return const DashboardScreen();
    } else {
      return const LoginScreen();
    }
  }
}
