import 'package:supabase_flutter/supabase_flutter.dart';
import '../dashboard/task_model.dart';

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<Task>> fetchTasks() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        print('No user logged in for fetchTasks');
        throw Exception('No user logged in');
      }
      print('Fetching tasks for user_id: ${user.id}');

      final response = await _client
          .from('tasks')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false);

      print('Raw Supabase fetch response: $response');
      return (response as List<dynamic>).map((e) => Task.fromJson(e)).toList();
    } catch (e) {
      print('Exception in fetchTasks: $e');
      throw e;
    }
  }

  Future<void> addTask(String title) async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        print('No user logged in for addTask');
        throw Exception('User not logged in');
      }
      print('Inserting task with title: $title, user_id: ${user.id}');

      await _client.from('tasks').insert({
        'title': title,
        'user_id': user.id,
        'is_done': false,
        'created_at': DateTime.now().toIso8601String(),
      });

      print('Task inserted successfully: $title');
    } catch (e) {
      print('Exception in addTask: $e');
      throw e;
    }
  }

  Future<void> deleteTask(String id) async {
    try {
      print('Deleting task with id: $id');
      await _client.from('tasks').delete().eq('id', id);
      print('Task deleted successfully: id=$id');
    } catch (e) {
      print('Exception in deleteTask: $e');
      throw e;
    }
  }
}